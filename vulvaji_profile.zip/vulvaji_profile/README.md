my personal site on github. click preview @ [mrsrinivas.github.io](https://mrsrinivas.github.io/)
